import random
import tasks



def SuperFunction():
    a = random.choice(tasks.stack_of_functions)
    return a


if __name__ == "__main__":
    ...

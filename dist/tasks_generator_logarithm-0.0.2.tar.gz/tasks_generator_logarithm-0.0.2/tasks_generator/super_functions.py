import random
import tasks_generator



def super_function():
    a = random.choice(tasks_generator.stack_of_functions)
    return a


if __name__ == "__main__":
    ...

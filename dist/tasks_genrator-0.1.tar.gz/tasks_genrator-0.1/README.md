# tasks_generator
Tasks_generator
This is a generator of math tasks with using logarythmic functions for education.
